# Introduction

These notes summarize core data structures with a focus on Abstract Data Types (ADTs), their operations, and implementation trade-offs. For each structure, you will find:

- **ADT definition**: the contract of operations and expected behavior.
- **Complexities**: typical time and space characteristics.
- **Implementation tips**: practical considerations or edge cases.

Conventions used across the notes:
- `n` denotes the number of elements.
- Complexities are worst-case unless noted.
- Pseudocode favors clarity over language-specific syntax.
